<?php
$server = "http://localhost/OnePay";
$auth = "Basic dGVzdDp0ZXN0";

?>

<input type="hidden" id="server_" value="<?php echo $server; ?>">
<input type="hidden" id="auth_" value="<?php echo $auth; ?>">
