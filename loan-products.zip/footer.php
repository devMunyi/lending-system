<div id="mainModal" class="modal fade" role="dialog">
    Loading...
</div>

<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.4.18
    </div>
    <strong>Copyright &copy; <?php echo date("Y") ?> <a target="_blank" href="https://www.onepay.co.ke">One Pay</a>.</strong> All rights
    reserved. <a onclick="modal_view('/jresources/confirm_example','')">Open Modal</a>
</footer>

<?php
include_once "configs/20200902.php";
?>