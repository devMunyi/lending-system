<div class="row">
    <div class="col-lg-8 col-xs-8">
        <!-- small box -->
        <div class="box box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">Time Performance</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                jfjfj
            </div>
            <!-- /.box-body -->
        </div>
    </div>
    <div class="col-lg-4 col-xs-4">
        <div class="box box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">ToDo</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                jfjfj
            </div>
            <!-- /.box-body -->
        </div>
    </div>
    <div class="col-lg-6 col-xs-6">
        <!-- small box -->
        <div class="box box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">Company Performance</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                jfjfj
            </div>
            <!-- /.box-body -->
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-6 col-xs-6">
        <!-- small box -->
        <div class="box box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">Branch Performance</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                jfjfj
            </div>
            <!-- /.box-body -->
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-6 col-xs-6">
        <!-- small box -->
        <div class="box box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">Product Performance</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                jfjfj
            </div>
            <!-- /.box-body -->
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-6 col-xs-6">
        <!-- small box -->
        <div class="box box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">Individual Performance</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                jfjfj
            </div>
            <!-- /.box-body -->
        </div>
    </div>

    <!-- ./col -->
</div>